# Twitter-Bot-Detection
This is a Flask based Web Apllication in which user can be predicted as Twitter Bots or Not.
